#ifndef BUTTON_FUNCTIONS
#define BUTTON_FUNCTIONS

void digit_init();
uint8_t chk_button(uint8_t button);
void segsum(uint16_t sum);
void toggle_button_bus();

#endif // BUTTON_FUNCTIONS